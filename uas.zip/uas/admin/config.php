<?php 
mysql_connect("localhost","id6518301_penitipankucing","anggun123","d6518301_kucing");
mysql_select_db("kucing");
?>