<?php 
include 'config.php';
$nama=$_POST['nama'];
$kode=$_POST['kode'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$jenis_kucing=$_POST['jenis_kucing'];
//$modal=$_POST['modal'];
//$harga=$_POST['harga'];
//$jumlah=$_POST['jumlah'];
//$sisa=$_POST['jumlah'];

mysql_query("insert into data_kucing values('','$kode','$nama','$jenis_kelamin','$jenis_kucing')");
header("location:data_kucing.php");

 ?>